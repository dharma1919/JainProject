package com.Stepdefination;

import java.io.IOException;

import com.pages.SelectBasket;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class SelBasketStep  extends SelectBasket
{
	@Given("^the user launch the chrome application$")
	public void the_user_launch_the_chrome_application() 
	{
	
		launchbrowser("chrome");
	}

	@When("^the user click on the login page and enters the username and password$")
	public void the_user_click_on_the_login_page_and_enters_the_username_and_password() throws IOException 
	{
		Mylogin();

	}

	@Then("^the user enters the search data with in the search page\\.$")
	public void the_user_enters_the_search_data_with_in_the_search_page() throws InterruptedException  
	{
		shoppingbasket();
		Selectbasket();
		
		
	}

	@Then("^the user click on the Go option$")
	public void the_user_click_on_the_Go_option() 
	{
		moveListItems();
		
	}
	@Then ("^the user logout from the website and closes the browser$")
	public void the_user_logout_from_the_website_and_closes_the_browser() throws InterruptedException 
	{
		logOutPage();
		
	}


}
